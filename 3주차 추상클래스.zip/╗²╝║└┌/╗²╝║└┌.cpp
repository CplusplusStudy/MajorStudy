#include <iostream>
using namespace std;

class Parent{  
    int a;
public:
    Parent(int a) : a(a)
    {
        cout << "Parent����" << endl;
    }

    virtual void print() = 0;

    void print(int a)
    {
        cout << a << endl;
    }
    virtual ~Parent()
    {
        cout << "parent �Ҹ�" << endl;
    }
};

class Child : public Parent
{
public:
    Child(int a) : Parent(a)
    {
        cout << "child����" << endl;
    }
    ~Child()
    {
        cout << "child �Ҹ�" << endl;
    }
    void print() override { cout << "child" << endl; }
};


int main()
{
    Parent* p = new Child(1);
    //Child* c = new Child(2);

    //p->print();
    //c->print();

    //c->print(2);

    

    delete p;
   //delete c;

    return 0;
}