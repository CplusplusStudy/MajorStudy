#include <iostream>
using namespace std;

#include <iostream>

class Parent {  // ����Ŭ����, interface
public:
    
};

class Child : public Parent
{
public:
    void print() override { cout << "child" << endl; }
};


int main()
{
    //Parent* X = new Parent();
    Parent* p = new Child();
    Child* c = new Child();

    p->print();
    c->print();
    return 0;
}