#include <iostream>
using namespace std;

class Parent {
public:
    void print1() 
    {
        cout << "parent print1" << endl;
    }
    virtual void print2() 
    {
        cout << "parent print2" << endl;
    }
    virtual void print3() 
    {
        cout << "parent print3" << endl;
    }
};

class Child1 : public Parent {
public:
    void print2() 
    {
        cout << "child1 print2" << endl;
    }
    void print3(int x) 
    {
        cout << "child1 print3" << endl;
    }
};

class Child2 : public Parent {
public:
    void print2()
    {
        cout << "child2 print2" << endl;
    }
    void print3()
    {
        cout << "child2 print3" << endl;;
    }
};

int main() 
{
    Parent* p;
    Child1 c1;
    p = &c1;

    p->print1();
    p->print2();
    p->print3();
    cout << "----------------" <<endl;

    Parent* child1 = new Child1();
    Parent* child2 = new Child2();

    child1->print2();
    child2->print2();

    return 0;
}